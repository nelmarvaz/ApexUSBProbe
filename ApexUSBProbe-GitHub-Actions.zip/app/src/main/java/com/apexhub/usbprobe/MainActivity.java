package com.apexhub.usbprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
  UsbManager manager; TextView output; LinearLayout list; String lastReport="";
  int bg=0xff0e0d10, panel=0xff252126, accent=0xffff7a1a;
  @Override public void onCreate(Bundle state){super.onCreate(state);manager=(UsbManager)getSystemService(USB_SERVICE);render();}
  TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(12,12,12,12);return t;}
  Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));return b;}
  void render(){ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(14,24,14,24);sc.addView(root);
    TextView title=text("◈ APEX HUB  /  USB PROBE",22);title.setTextColor(accent);root.addView(title);
    root.addView(text("Diagnóstico somente leitura • ATK Zero + Akko 5087 V3 HE",13));
    Button refresh=button("Atualizar dispositivos USB");root.addView(refresh);
    Button share=button("Compartilhar relatório");root.addView(share);
    list=new LinearLayout(this);list.setOrientation(1);root.addView(list);
    output=text("",12);output.setTextIsSelectable(true);root.addView(output);setContentView(sc);
    refresh.setOnClickListener(v->scan());share.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,lastReport);startActivity(Intent.createChooser(i,"Compartilhar diagnóstico"));});scan();}
  String hex(int n){return String.format(Locale.US,"%04X",n);}
  void scan(){list.removeAllViews();StringBuilder report=new StringBuilder("APEX USB PROBE — Android "+Build.VERSION.RELEASE+"\n\n");
    HashMap<String,UsbDevice> devices=manager.getDeviceList();report.append("Dispositivos: ").append(devices.size()).append("\n");
    if(devices.isEmpty())list.addView(text("Nenhum dispositivo USB detectado. Conecte o hub USB-C e toque em Atualizar.",15));
    for(UsbDevice d:devices.values()){
      String name="VID "+hex(d.getVendorId())+"  PID "+hex(d.getProductId());
      Button item=button(name+"  •  "+d.getInterfaceCount()+" interfaces");list.addView(item);
      StringBuilder detail=new StringBuilder();detail.append("\n").append(name).append("\n");
      detail.append("Nome: ").append(d.getDeviceName()).append("\n");
      detail.append("Classe/subclasse/protocolo: ").append(d.getDeviceClass()).append("/").append(d.getDeviceSubclass()).append("/").append(d.getDeviceProtocol()).append("\n");
      detail.append("Permissão: ").append(manager.hasPermission(d)?"SIM":"NÃO").append("\n");
      if(manager.hasPermission(d)){detail.append("Fabricante: ").append(d.getManufacturerName()).append("\nProduto: ").append(d.getProductName()).append("\nSerial: ").append("[omitido por privacidade]").append("\n");}
      for(int j=0;j<d.getInterfaceCount();j++){UsbInterface f=d.getInterface(j);detail.append("  Interface ").append(j).append(" ID ").append(f.getId()).append(" alt ").append(f.getAlternateSetting()).append(" classe/sub/proto ").append(f.getInterfaceClass()).append("/").append(f.getInterfaceSubclass()).append("/").append(f.getInterfaceProtocol()).append("\n");
        for(int k=0;k<f.getEndpointCount();k++){UsbEndpoint e=f.getEndpoint(k);detail.append("    EP ").append(k).append(" addr 0x").append(Integer.toHexString(e.getAddress())).append(" ").append(e.getDirection()==UsbConstants.USB_DIR_IN?"IN":"OUT").append(" tipo ").append(e.getType()).append(" maxPacket ").append(e.getMaxPacketSize()).append(" interval ").append(e.getInterval()).append("\n");}}
      report.append(detail);item.setOnClickListener(v->{output.setText(detail.toString());if(!manager.hasPermission(d)){new AlertDialog.Builder(this).setTitle("Permissão USB").setMessage("Deseja solicitar acesso a este dispositivo? Nenhum comando será enviado.").setPositiveButton("Solicitar",(dialog,w)->request(d)).setNegativeButton("Cancelar",null).show();}});
    }
    lastReport=report.toString();output.setText(lastReport);
  }
  void request(UsbDevice d){String action=getPackageName()+".USB_PERMISSION";PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(action).setPackage(getPackageName()),PendingIntent.FLAG_IMMUTABLE);manager.requestPermission(d,pi);new AlertDialog.Builder(this).setMessage("Após responder à permissão do Android, toque em Atualizar dispositivos USB.").setPositiveButton("OK",null).show();}
}
