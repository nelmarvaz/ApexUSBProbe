# Apex USB Probe

Projeto Android nativo, somente diagnóstico de descritores USB. Não reivindica interfaces e não envia comandos HID.

## Compilar
1. Abra esta pasta no Android Studio (versão recente com suporte ao Android Gradle Plugin 8.7.3).
2. Aguarde o Gradle Sync (requer internet para dependências e Android SDK 35).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Instale `app/build/outputs/apk/debug/app-debug.apk` no Galaxy S23 FE.
5. Conecte hub USB-C, teclado e mouse/dongle. Toque **Atualizar dispositivos USB** e compartilhe o relatório.

O Android pode exigir permissão para acessar fabricante/produto. O relatório omite o número de série por privacidade. Não há acesso a bateria ou comandos de configuração nesta versão.

## Compilar pelo GitHub Actions (sem PC)
Crie um repositório no GitHub e envie **o conteúdo desta pasta para a raiz do repositório**, incluindo `.github/workflows/android-apk.yml`.
Na aba Actions, abra `Compilar APK Android`, clique em `Run workflow` e aguarde a execução.
Ao finalizar, abra a execução e baixe o artifact `ApexUSBProbe-debug-apk`. Extraia o ZIP para obter `app-debug.apk`.
O APK é de teste (debug), não destinado à publicação. O build precisa de internet para baixar o Android SDK/Gradle.
