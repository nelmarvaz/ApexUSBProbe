plugins { id("com.android.application") }
android { namespace = "com.apexhub.usbprobe"; compileSdk = 35
 defaultConfig { applicationId = "com.apexhub.usbprobe"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" } }
